MOSS family display assets
The corrected MOSS mark reads MO / SS in a two-by-two layout.
The green O contains a cartoon qubit arc and red state dot.
The icon is the original transparent PNG, not a vector tracing.
Package and repository names retain their canonical MOSS names.
Package wordmarks are separate SVG paths with light/dark and compact variants.
Keep the original aspect ratio. The icon artwork is identical across the family.
