MOSS family display assets
The approved MOOS mark reads MO / OS in a two-by-two layout.
The green and purple O letters contain cartoon qubit arcs and red state dots.
The icon is the original transparent PNG, not a vector tracing.
Package and repository names retain their canonical MOSS names.
Package wordmarks are separate SVG paths with light/dark and compact variants.
Keep the original aspect ratio. The icon artwork is identical across the family.
